package adapter;

public class CreateAuto extends ProxyAutomobile implements BuildAuto, UpdateAuto, ChooseAuto {

}
